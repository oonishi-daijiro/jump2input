chrome.commands.onCommand.addListener((command) => {
  getCurrentTab().then(tab => {
    chrome.tabs.sendMessage(tab.id, "shortcut")
  }).catch(error => {
    console.log(error)
  })
});

async function getCurrentTab() {
  return await new Promise((resolve, reject) => {
    chrome.tabs.query({
      active: true,
      lastFocusedWindow: true
    }, result => {
      if (result[0] === undefined) {
        reject(result)
      }
      resolve(result[0])
    })
  })
}
